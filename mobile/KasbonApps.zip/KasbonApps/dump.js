import { StyleSheet, Text, TouchableHighlight, View } from "react-native";
import React from "react";
import { Button } from 'react-native-paper';

export default function SplashScreen({ navigation }) {
  const goToRoute = (nameRoute) => {
    navigation.navigate(nameRoute);
  };
  return (
    <View style={styles.container}>
      <View>
        <Text>SplashScreen</Text>
        {/* <TouchableHighlight onPress={() => goToRoute("LoginScreen")}>
          <Text>Goto Loginpage</Text>
        </TouchableHighlight> */}
        <Button icon="arrow-right" contentStyle={{ flexDirection: 'row-reverse' }} mode="contained" onPress={() => goToRoute("LoginScreen")}>
          Goto Loginpage
        </Button>
      </View>
      {/* row */}
      <View style={styles.row}>
        {/* kolom */}
        <View style={styles.column}>
          {/* Content for the first grid item */}
          <Text>1</Text>
          <Text>1</Text>
          <Text>1</Text>
          <Text>1</Text>
          <Text>1</Text>

          {/* row */}
          <View style={styles.row}>
            {/* kolom */}
            <View style={styles.column}>
              {/* Content for the first grid item */}
              <Text>1</Text>
            </View>
            <View style={styles.column}>
              {/* Content for the first grid item */}
              <Text>1</Text>
            </View>
            <View style={styles.column}>
              {/* Content for the first grid item */}
              <Text>1</Text>
            </View>
            <View style={styles.column}>
              {/* Content for the first grid item */}
              <Text>1</Text>
            </View>
            <View style={styles.column}>
              {/* Content for the first grid item */}
              <Text>1</Text>
            </View>
            <View style={styles.column}>
              {/* Content for the first grid item */}
              <Text>1</Text>
            </View>
            {/* [end] kolom */}
          </View>
          {/* [end] row */}
        </View>
        {/* [end] kolom */}

        <View style={styles.column}>
          {/* Content for the first grid item */}
          <Text>1</Text>
        </View>
        <View style={styles.column}>
          {/* Content for the first grid item */}
          <Text>1</Text>
        </View>
      </View>
      {/* [end] row */}

      {/* row */}
      <View style={styles.row}>
        {/* kolom */}
        <View style={styles.column}>
          {/* Content for the first grid item */}
          <Text>1</Text>
        </View>
        <View style={styles.column}>
          {/* Content for the second grid item */}
          <Text>2</Text>
        </View>
        <View style={styles.column}>
          {/* Content for the second grid item */}
          <Text>3</Text>
        </View>
        <View style={styles.column}>
          {/* Content for the second grid item */}
          <Text>3</Text>
        </View>
        <View style={styles.column}>
          {/* Content for the second grid item */}
          <Text>3</Text>
        </View>
        <View style={styles.column}>
          {/* Content for the second grid item */}
          <Text>3</Text>
        </View>
      </View>
      <View style={styles.row}>
        <View style={styles.column}>
          {/* Content for the third grid item */}
          <Text>3</Text>
        </View>
        <View style={styles.column}>
          {/* Content for the fourth grid item */}
          <Text>4</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  row: {
    flexDirection: "row",
  },
  column: {
    flex: 1,
    padding: 10,
  },
});
