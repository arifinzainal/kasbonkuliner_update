import axios from 'axios';
import * as SecureStore from 'expo-secure-store';

// Create an instance of Axios with custom configurations
const api = axios.create({
  // baseURL: 'http://localhost:8000/api',
  baseURL: 'http://192.168.1.27:8000/api', // Your API base URL
  timeout: 5000, // Request timeout in milliseconds
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  async (config) => {
    // Add any request transformations here, such as adding headers or modifying data
    let token = await SecureStore.getItemAsync('token')
    if(token !== null) {
      config.headers.Authorization = `Bearer ${token}`
    }
    // console.log(config)
    return config;
  },
  (error) => {
    // Handle request errors
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => {
    // Add any response transformations here, such as modifying response data
    return response;
  },
  (error) => {
    // Handle response errors
    return Promise.reject(error);
  }
);

export default api;