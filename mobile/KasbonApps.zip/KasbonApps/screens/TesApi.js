import { StyleSheet, Text, View, TextInput } from "react-native";
import React, { useState } from "react";
import { Button } from "react-native-paper";
import globalStyle from "../styles/GlobalStyle";
import api from "../utils/HttpReq";
// import axios from 'axios';

export default function SplashScreen({ navigation }) {
  const goToRoute = (nameRoute) => {
    navigation.navigate(nameRoute);
  };

  const [idm, setIdm] = useState();

  const handleidm = (text) => {
    setIdm(text); // Update the state with the entered value
  };

  const [dataAtas, setData] = useState(null);

  const getData = async () => {
    if (idm === null) {
      idm = 9
    }
    const tmpdata = await api.get("/todos/");
    console.log(tmpdata);
    setData(tmpdata);
    //   axios.get('https://jsonplaceholder.typicode.com/todos/1')
    // .then(response => {
    //   console.log(response.data);
    // })
    // .catch(error => {
    //   console.error(error);
    // });
  };
  return (
    <View style={globalStyle.container}>
      <View>
        <TextInput
          value={idm} // Set the value of TextInput to the state value
          onChangeText={handleidm} // Call the function on value change
        />
        <View style={{alignItems: 'center', justifyContent: "center", margin: 20}}>
        <Text>No : {dataAtas && (dataAtas.data[idm-1].id).toString()}</Text>
        <Text>Title : {dataAtas && (dataAtas.data[idm-1].title).toString()}</Text>
        <Text>Completed : {dataAtas && (dataAtas.data[idm-1].completed).toString()}</Text>
        </View>
        
        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => getData()}
          style={globalStyle.txt}
        >
          GetDatabiss
        </Button>

        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => goToRoute("SplashScreen")}
          style={globalStyle.txt}
        >
          Goto Home
        </Button>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  row: {
    flexDirection: "row",
  },
  column: {
    flex: 1,
    padding: 10,
  },
});
