import {Text, TouchableHighlight, StyleSheet, View,}
from "react-native";
import * as React from 'react';
import globalStyle from "../styles/GlobalStyle";
import {Button,TextInput,} from 'react-native-paper'

export default function LoginScreen2({ navigation }) {

  // -- state variabel
  const [text, setText] = React.useState("");
  const [password, setPassword] = React.useState('');
  // -- state variabel [end]
  
  const goToRoute = (nameRoute) => {
    navigation.navigate(nameRoute);
  };


  return (
    <View style={globalStyle.container}>
    <View>
    <View style={globalStyle.row}>
      <Text>Username</Text>
    </View>

    <TextInput
      style={{margin: 10}}
      label="Username"
      value={text}
      onChangeText={text => setText(text)}
    />

    <View style={globalStyle.row}>
      <Text>Password</Text>
    </View>

    <TextInput
      style={{margin: 10}}
      label="Password"
      value={password}
      onChangeText={password => setPassword(password)}
      secureTextEntry={true}
    />
      <Button contentStyle={{ flexDirection: "row-reverse" }} mode="contained" style={{margin: 10}} onPress={() => goToRoute ("HomeScreen")}>
        Login
      </Button>
    </View>
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    width: "50%",
  },
});
