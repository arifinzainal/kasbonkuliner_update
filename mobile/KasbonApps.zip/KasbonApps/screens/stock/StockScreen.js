import { StyleSheet, TextInput, View, Alert } from "react-native";
import React, { useState } from "react";
// import { ScrollView } from "react-native-web";
import {
  DataTable,
  FAB,
  Modal,
  Portal,
  Text,
  Button,
  PaperProvider,
} from "react-native-paper";
import globalStyle from "../../styles/GlobalStyle";
import api from "../../utils/HttpReq";
import * as SecureStore from "expo-secure-store";

export default function StockScreen({ navigation }) {
  const [visible, setVisible] = useState(false);

  const showModal = () => setVisible(true);
  const hideModal = () => setVisible(false);

  const goToRoute = (nameRoute) => {
    navigation.navigate(nameRoute);
  };

  const [dataAtas, setData] = useState(null);

  const getdata = async () => {
    let payload = {};
    try {
      let response = await api.get("/cashier/product", payload);
      if (response.status === 200) {
        // jika sukses ngapain?
        // let data = response.data.data;
        setData(response);
      } else {
        alert("Data Kosong!");
      }
    } catch (error) {
      Alert.alert("Error", "Data Kosong!");
    }
  };
  return (
    <View style={globalStyle.flex}>
      <PaperProvider>
        <View style={globalStyle.headers}>
          <TextInput
            style={globalStyle.txtwhite}
            placeholder="Cari barang"
            placeholderTextColor="silver"
          />
        </View>
        <DataTable style={{ color: "#0f0" }}>
          <DataTable.Header>
            <DataTable.Title>Jenis Bahan</DataTable.Title>
            <DataTable.Title>Satuan</DataTable.Title>
            <DataTable.Title>Fat</DataTable.Title>
          </DataTable.Header>

          {dataAtas && dataAtas.data.data.map(val => {
              return (
                <>
                  {/* <Text>{v.title}</Text> */}
                  <DataTable.Row onPress={() => goToRoute("DetailStockScreen")}>
                    <DataTable.Cell>{val.name}</DataTable.Cell>
                    <DataTable.Cell>{val.size_variations && val.size_variations[0].size}</DataTable.Cell>
                    <DataTable.Cell>{val.size_variations && val.size_variations[0].stock}</DataTable.Cell>
                  </DataTable.Row>
                </>
              );
            })}

          <DataTable.Row onPress={() => goToRoute("DetailStockScreen")}>
            <DataTable.Cell>Telur Ayam</DataTable.Cell>
            <DataTable.Cell>Kg</DataTable.Cell>
            <DataTable.Cell>50</DataTable.Cell>
          </DataTable.Row>

          <DataTable.Row onPress={() => getdata()}>
            <DataTable.Cell>Tepung</DataTable.Cell>
            <DataTable.Cell>g</DataTable.Cell>
            <DataTable.Cell>70</DataTable.Cell>
          </DataTable.Row>
        </DataTable>
        <FAB
          icon="plus"
          style={globalStyle.fab}
          onPress={showModal}
          color="#ffffff"
        />
        <Portal>
          <Modal
            visible={visible}
            onDismiss={hideModal}
            contentContainerStyle={globalStyle.modal}
          >
            <Text style={globalStyle.textModal}>Tambah Stok</Text>
            <TextInput
              style={globalStyle.textInput}
              placeholder="Jenis"
              placeholderTextColor="silver"
            />
            <TextInput
              style={globalStyle.textInput}
              placeholder="Satuan"
              placeholderTextColor="silver"
            />
            <View style={globalStyle.buttonModal}>
              <Button style={globalStyle.batal}>Batal</Button>
              <Button style={globalStyle.simpan}>Simpan</Button>
            </View>
          </Modal>
        </Portal>
      </PaperProvider>
    </View>
  );
}

const styles = StyleSheet.create({});
