import { StyleSheet, TextInput, View } from "react-native";
import * as React from "react";
import { ScrollView } from "react-native-web";
import {
  DataTable,
  FAB,
  Modal,
  Portal,
  Text,
  Button,
  PaperProvider,
} from "react-native-paper";
import globalStyle from "../../styles/GlobalStyle";
import { TouchableOpacity } from "react-native-gesture-handler";

export default function ManageStockScreen({ navigation }) {
  const [visible, setVisible] = React.useState(false);

  const showModal = () => setVisible(true);
  const hideModal = () => setVisible(false);

  const goToRoute = (nameRoute) => {
    navigation.navigate(nameRoute);
  };
  return (
    <View style={globalStyle.flex}>
      <PaperProvider>
        <View style={globalStyle.headers}>
        </View>
        <DataTable style={{ color: "#0f0" }}>
          <DataTable.Header style={{justifyContent: 'space-evenly' }}>
            <DataTable.Title>Kode</DataTable.Title>
            <DataTable.Title>Nama</DataTable.Title>
            <DataTable.Title>Stok</DataTable.Title>
            <DataTable.Title>Aksi</DataTable.Title>
          </DataTable.Header>

          <DataTable.Row>
            <DataTable.Cell>A001</DataTable.Cell>
            <DataTable.Cell>Telur Ayam</DataTable.Cell>
            <DataTable.Cell>25</DataTable.Cell>
            <DataTable.Cell>
              <View style={{ flexDirection: "row" }}>
                <TouchableOpacity><Text>Edit |</Text></TouchableOpacity>
                <TouchableOpacity onPress={showModal}><Text>| Hapus</Text></TouchableOpacity>
              </View>
            </DataTable.Cell>
          </DataTable.Row>

          <DataTable.Row>
            <DataTable.Cell>A001</DataTable.Cell>
            <DataTable.Cell>Telur Ayam</DataTable.Cell>
            <DataTable.Cell>25</DataTable.Cell>
            <DataTable.Cell>
              <View style={{ flexDirection: "row" }}>
                <TouchableOpacity><Text>Edit |</Text></TouchableOpacity>
                <TouchableOpacity onPress={showModal}><Text>| Hapus</Text></TouchableOpacity>
              </View>
            </DataTable.Cell>
          </DataTable.Row>
        </DataTable>
        <Portal>
          <Modal
            visible={visible}
            onDismiss={hideModal}
            contentContainerStyle={globalStyle.modal}
          >
            <Text style={globalStyle.textModal}>Anda yakin ingin hapus?</Text>
          
            <View style={globalStyle.Modalhapus}>
              <Button style={globalStyle.simpan}>Batal</Button>
              <Button style={globalStyle.batal}>Hapus</Button>
            </View>
          </Modal>
        </Portal>
      </PaperProvider>
    </View>
  );
}

const styles = StyleSheet.create({});
