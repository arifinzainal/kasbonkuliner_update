import { StyleSheet, TextInput, View } from "react-native";
import * as React from "react";
import { ScrollView } from "react-native-web";
import api from "../../utils/HttpReq";
import { FAB, Alert,Text, Button, IconButton } from "react-native-paper";
import globalStyle from "../../styles/GlobalStyle";

export default function Kasir({navigation}) {
  const [dataKategori, setDataKategori] = React.useState([])
  const goToRoute = (nameRoute) => {
    navigation.navigate(nameRoute);
  };

  const getDataProduct = async () => {
    let payload = {};
    try {
      let response = await api.get("/category/makanan", payload);
      console.log(response);
      if (response.status === 200) {
        // jika sukses ngapain?
        let data = response.data;
        let arr = Object.keys(data.data).map(v => data.data[v])
        console.log(arr[0], 'datanya')
        setDataKategori(arr)
      } else {
        alert("Hello I am Simple Alert");
      }

    } catch (error) {
      console.log(error);
      Alert.alert("Error", "error sesuatu..");
    }
  };

  return (
    <View style={styles.container}>
      <View style={globalStyle.headers}>
        <TextInput
          style={globalStyle.txtwhite}
          placeholder="Cari barang"
          placeholderTextColor="silver"
        />
      </View>
      <View style={styles.item}>
        <View style={{ flexDirection: "row", paddingBottom: 10 }}>
          <IconButton
            icon="minus"
            color="#FF0000"
            size={24}
            onPress={() => console.log("Pressed")}
          />
          <View>
            <Text style={{ paddingLeft: 10, paddingTop: 5, color: "white" }}>
              Es Teh
            </Text>
            <Text style={{ paddingTop: 10, paddingLeft: 10, color: "white" }}>
              Rp 5.000
            </Text>
          </View>
          <View
            style={{
              justifyContent: "center",
              alignItems: "flex-end",
              paddingHorizontal: 20,
              flex: 1,
            }}
          >
            <Text style={{ textAlign: "right", color: "white" }}>QTY:</Text>
          </View>
        </View>
      </View>

{dataKategori.map(val => {
      return (<View style={styles.item}>
        <View style={{ flexDirection: "row", paddingBottom: 10 }}>
          <IconButton
            icon="minus"
            color="white"
            backgroundColor="white"
            size={24}
            onPress={() => console.log("Pressed")}
          />
          <View>
            <Text style={{ paddingLeft: 10, paddingTop: 5, color: "white" }}>
              {val.name}
            </Text>
            <Text style={{ paddingTop: 10, paddingLeft: 10, color: "white" }}>
            {val.product_price.price}
            </Text>
          </View>
          <View
            style={{
              justifyContent: "center",
              alignItems: "flex-end",
              paddingHorizontal: 20,
              flex: 1,
            }}
          >
            <Text style={{ textAlign: "right", color: "white" }}>QTY:</Text>
          </View>
        </View>
      </View>
      )
})}
      {/* <View style={styles.item}>
        <View style={{ flexDirection: "row", paddingBottom: 10 }}>
          <IconButton
            icon="minus"
            color="white"
            backgroundColor="white"
            size={24}
            onPress={() => console.log("Pressed")}
          />
          <View>
            <Text style={{ paddingLeft: 10, paddingTop: 5, color: "white" }}>
              Es Teh
            </Text>
            <Text style={{ paddingTop: 10, paddingLeft: 10, color: "white" }}>
              Rp 5.000
            </Text>
          </View>
          <View
            style={{
              justifyContent: "center",
              alignItems: "flex-end",
              paddingHorizontal: 20,
              flex: 1,
            }}
          >
            <Text style={{ textAlign: "right", color: "white" }}>QTY:</Text>
          </View>
        </View>
      </View> */}
      <View
        style={{
          flex: 1,
          justifyContent: "flex-end",
          alignItems: "flex-end",
          margin: 16,
        }}
      >
        <Button
          mode="contained"
          onPress={() => goToRoute("Pembayaran")}
          style={styles.button}
        >Buyer
        </Button>

        <Button
          mode="contained"
          onPress={() =>getDataProduct()}
        >Tester
        </Button>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  item: {
    backgroundColor: "#6666ff",
    height: 60,
    marginTop: 5,
    padding: 5,

  },
  button: {
    position: "absolute",
    bottom: 0,
    right: 0,
    flex: 1,
    justifyContent: "flex-end",
  },
  container: {
    flex: 1,
    backgroundColor: "#F5FCFF",
  },
});
