import { StyleSheet, Text, View, Image } from "react-native";
import React from "react";
import {
  Avatar,
  Button,
  IconButton,
  MD3Colors,
  Title,
  TextInput,
  Card,
  PaperProvider,
  Modal,
  Portal,
} from "react-native-paper";
import imgIcon from "../../assets/kasbon.jpg";
import globalStyle from "../../styles/GlobalStyle";

const containerStyle = {
  backgroundColor: "#6666ff",
  marginTop: 40,
  width: 375,
  height: 460,
};
export default function Pembayaran() {
  const [visible, setVisible] = React.useState(false);
  const showModal = () => setVisible(true);
  const hideModal = () => setVisible(false);
  return (
    <View style={globalStyle.flex}>
      <PaperProvider>
        <Image source={imgIcon} style={{ width: "100%", height: 100 }} />
        <View style={containerStyle}>
          <View style={{ flexDirection: "column", alignSelf: "center" }}>
            <Text style={{ paddingTop: 5, color: "white" }}>
              Total yang harus dibayar
            </Text>
            <Text style={{ paddingTop: 5, color: "white" }}>Rp 0</Text>
          </View>

          <View
            style={{ flexDirection: "row", paddingTop: 20, paddingLeft: 20 }}
          >
            <Text style={{ color: "white", paddingTop: 5 }}>
              Bayar pakai tunai
            </Text>
            <TextInput
              style={{ width: 125, height: 35, marginLeft: 20 }}
              placeholder="Rp 0"
            />
          </View>

          <View
            style={{ flexDirection: "row", paddingTop: 20, paddingLeft: 20 }}
          >
            <Text style={{ color: "white", paddingTop: 5 }}>Kembalian</Text>
            <TextInput
              style={{ width: 125, height: 35, marginLeft: 60 }}
              placeholder="Rp 0"
            />
          </View>

          <View
            style={{ flexDirection: "row", paddingTop: 20, paddingLeft: 20 }}
          >
            <Text style={{ color: "white" }}>Pilih Pembayaran</Text>
          </View>

          <View
            style={{ flexDirection: "row", paddingTop: 10, paddingLeft: 20 }}
          >
            <Card style={{ width: 50, marginHorizontal: 5 }}>
              <Card.Cover
                source={require("../../assets/rp.jpg")}
                style={{ height: 50, width: 50 }}
              />
            </Card>
            <Card style={{ width: 50, marginHorizontal: 5 }}>
              <Card.Cover
                source={require("../../assets/gopay.jpg")}
                style={{ height: 50, width: 50 }}
              />
            </Card>
            <Card style={{ width: 50, marginHorizontal: 5 }}>
              <Card.Cover
                source={require("../../assets/dana.jpg")}
                style={{ height: 50, width: 50 }}
              />
            </Card>
            <Card style={{ width: 50, marginHorizontal: 5 }}>
              <Card.Cover
                source={require("../../assets/ofo.jpg")}
                style={{ height: 50, width: 50 }}
              />
            </Card>
            <Card style={{ width: 50, marginHorizontal: 5 }}>
              <Card.Cover
                source={require("../../assets/spay.jpg")}
                style={{ height: 50, width: 50 }}
              />
            </Card>
          </View>

          <View
            style={{ flexDirection: "row", paddingTop: 20, paddingLeft: 20 }}
          >
            <Text style={{ color: "white" }}>Input Nominal</Text>
          </View>

          <View
            style={{ flexDirection: "row", paddingTop: 10, paddingLeft: 3 }}
          >
            <Button
              style={{ marginHorizontal: 1.25, width: 120, height: 35 }}
              mode="contained"
              onPress={() => console.log("Pressed")}
            >
              Rp 1.000
            </Button>
            <Button
              style={{ marginHorizontal: 1.25, width: 120, height: 35 }}
              mode="contained"
              onPress={() => console.log("Pressed")}
            >
              Rp 2.000
            </Button>
            <Button
              style={{ marginHorizontal: 1.25, width: 120, height: 35 }}
              mode="contained"
              onPress={() => console.log("Pressed")}
            >
              Rp 5.000
            </Button>
          </View>

          <View
            style={{ flexDirection: "row", paddingTop: 10, paddingLeft: 3 }}
          >
            <Button
              style={{ marginHorizontal: 1.25, width: 120, height: 35 }}
              mode="contained"
              onPress={() => console.log("Pressed")}
            >
              Rp 20.000
            </Button>
            <Button
              style={{ marginHorizontal: 1.25, width: 120, height: 35 }}
              mode="contained"
              onPress={() => console.log("Pressed")}
            >
              Rp 50.000
            </Button>
            <Button
              style={{ marginHorizontal: 1.25, width: 120, height: 35 }}
              mode="contained"
              onPress={() => console.log("Pressed")}
            >
              Rp 100.000
            </Button>
          </View>

          <View
            style={{ flexDirection: "row", paddingTop: 25, paddingLeft: 260 }}
          >
            <Button
              style={{ marginHorizontal: 1.25, width: 100, height: 35 }}
              mode="contained"
              onPress={() => showModal()}
            >
              Bayar
            </Button>
          </View>
        <Portal>
        <Modal
            visible={visible}
            onDismiss={hideModal}
            contentContainerStyle={{...globalStyle.modal, height: 400,}}>
        <View style={{flexDirection: 'row' , justifyContent: 'center'}}>
        <View>
            <IconButton
                icon="cash-check"
                color="#FF0000"
                size={100}
                onPress={() => console.log("Pressed")}/>
            <Text>Pembayaran Sukses</Text>
            </View>
        </View>
        </Modal>
        </Portal>
        </View>
      </PaperProvider>
    </View>
  );
}

const styles = StyleSheet.create({});
