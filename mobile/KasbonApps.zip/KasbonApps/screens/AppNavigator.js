import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import LoginForm from './LoginForm';
import HomeScreen from './HomeScreen';

const AppNavigator = createStackNavigator(
  {
    Login: {
      screen: LoginForm,
      navigationOptions: {
        headerShown: false,
      },
    },
    HomeScreen: {
      screen: HomeScreen,
      navigationOptions: {
        title: 'Home',
      },
    },
  },
  {
    initialRouteName: 'Login',
  }
);

export default createAppContainer(AppNavigator);
