import { StyleSheet, Text, TouchableHighlight, View } from "react-native";
import React from "react";
import { Button } from "react-native-paper";
import globalStyle from '../styles/GlobalStyle'

export default function SplashScreen({ navigation }) {
  const goToRoute = (nameRoute) => {
    navigation.navigate(nameRoute);
  };
  return (
    <View style={globalStyle.container}>
      <View>
        <Text>SplashScreen</Text>
        {/* <TouchableHighlight onPress={() => goToRoute("LoginScreen")}>
          <Text>Goto Loginpage</Text>
        </TouchableHighlight> */}
        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => goToRoute("LoginScreen")}
          style={globalStyle.txt}
        >
          Goto Loginpage
        </Button>
        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => goToRoute("HomeScreen")}
          style={globalStyle.txt}
        >
          Goto Homepage
        </Button>
        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => goToRoute("MenuScreen")}
          style={globalStyle.txt}
        >
          Goto Menupage
        </Button>

        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => goToRoute("StockScreen")}
          style={globalStyle.txt}
        >
          Goto StockScreen
        </Button>

        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => goToRoute("MenuScreen2")}
          style={globalStyle.txt}
        >
          Goto Menu screen 2
        </Button>

        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => goToRoute("Transaksi")}
          style={globalStyle.txt}
        >
          Goto Transaksi
        </Button>

        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => goToRoute("FiturMenu")}
          style={globalStyle.txt}
        >
          Goto FiturMenu
        </Button>
      
        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => goToRoute("Pembayaran")}
          style={globalStyle.txt}
        >
          Goto Pembayaran
        </Button>

        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => goToRoute("Kasir")}
          style={globalStyle.txt}
        >
          Goto Kasir
        </Button>

        <Button
          icon="arrow-right"
          contentStyle={{ flexDirection: "row-reverse" }}
          mode="contained"
          onPress={() => goToRoute("TesApi")}
          style={globalStyle.txt}
        >
          Goto Api
        </Button>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  row: {
    flexDirection: "row",
  },
  column: {
    flex: 1,
    padding: 10,
  },
});
