import { StyleSheet, Text, View, SafeAreaView, ScrollView } from 'react-native'
import React, { useState } from 'react'
import { Button, RadioButton, IconButton, Card, Title, Divider, MD3Colors,DataTable } from 'react-native-paper';



export default function MenuScreen2({navigation}) {
  
  const goToRoute = (nameRoute) => {
    navigation.navigate(nameRoute);
  };
  const [value, setValue] = useState('');
  const RadioGroup = () => {
    const handlePress = (newValue) => {
        setValue(newValue);
      };
    }
  return (
    
    <ScrollView >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
      
      <View style={{ alignItems: 'center' }}>
      <IconButton icon="hamburger" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Burger</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="noodles" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Mie</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="coffee" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Minuman</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="rice" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Nasi</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="pizza" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Pizz</Text>
      </View>
      </View>

      <View style={{paddingTop:5}}>
        <Divider/>
      </View>

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
       <View style={{ alignItems: 'center', paddingLeft:20 }}>
        <IconButton icon="sort" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
        <Text style={{ fontSize:13 , paddingBottom:5 }}>Urutkan</Text>
      </View>

    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
      <RadioButton.Item
        label="Jenis"
        value="option1"
        status={value === 'option1' ? 'checked' : 'unchecked'}
        onPress={() => console.log('Pressed')}
      />
      <RadioButton.Item
        label="Harga"
        value="option2"
        status={value === 'option2' ? 'checked' : 'unchecked'}
        onPress={() => console.log('Pressed')}
      />
     </View>
    </View>
    
    <View>
        <Divider/>
    </View>

  <View style={{ flexDirection: 'row', paddingTop:5 }} >
    <View style={{ alignItems: 'center' }}>
      <Button icon="image" mode="elevated" onPress={() => goToRoute("FiturMenu")}>
        Gambar
      </Button>
    </View>

    <View style={{ paddingLeft:10 }}>
      <Button icon="table" mode="elevated" onPress={() => goToRoute("FiturMenu")}>
        Tabel
      </Button>
    </View>

  </View>

<View>
<View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/burger.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Burger</Title>
          </Card.Content>
      </Card>
      </View>

      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/burger2.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Chesse Burger</Title>
          </Card.Content>
      </Card>
      </View>
      </View>

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/burger3.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Big Mac</Title>
          </Card.Content>
      </Card>
      </View>

      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/burger.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Double beef</Title>
          </Card.Content>
      </Card>
      </View>
      </View>

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/burger2.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Double chesse</Title>
          </Card.Content>
      </Card>
      </View>

      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/burger3.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Big chesse</Title>
          </Card.Content>
      </Card>
      </View>
      </View>

      </View>

    </ScrollView>

  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    paddingTop: 10,
  },
})
