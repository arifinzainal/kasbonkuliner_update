import { StyleSheet, Text, View, ScrollView } from 'react-native'
import React, { useState } from 'react'
import { Button, RadioButton, IconButton, Card, Title, Divider, MD3Colors, SegmentedButtons, DataTable } from 'react-native-paper';


const SegmentedControl = () => {
  const [value, setValue] = useState('option1');

  const handleSegmentChange = (newValue) => {
    setValue(newValue);
  };

  return (
<ScrollView>
<View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
      
      <View style={{ alignItems: 'center' }}>
      <IconButton icon="hamburger" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Burger</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="noodles" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Love</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="coffee" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Love</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="rice" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Love</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="pizza" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Love</Text>
      </View>
      </View>

      <View style={{paddingTop:5}}>
        <Divider/>
      </View>

    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
       <View style={{ alignItems: 'center', paddingLeft:20 }}>
        <IconButton icon="sort" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
        <Text style={{ fontSize:13 , paddingBottom:5 }}>Urutkan</Text>
      </View>

   <View style={{ flexDirection: 'row' }}>
      <RadioButton.Group onValueChange={handleSegmentChange} value={value}>
        <View style={{ flexDirection: 'row' }}>
          <RadioButton.Item label="Jenis" value="option1" />
          <RadioButton.Item label="Harga" value="option2" />
        </View>
      </RadioButton.Group>
    </View>
  </View>

  <View style={{paddingTop:5}}>
      <Divider/>
  </View>

  <View style={{ flexDirection: 'row', paddingTop:5 }} >
    <View style={{ alignItems: 'center' }}>
      <Button icon="image" mode="contained" onPress={() => console.log('Pressed')}>
        Gambar
      </Button>
    </View>

    <View style={{ paddingLeft:10 }}>
      <Button icon="table" mode="contained" onPress={() => console.log('Pressed')}>
        Tabel
      </Button>
    </View>
  </View>

  <DataTable>
        <DataTable.Header>
          <DataTable.Title style={{justifyContent:'center'}}>Makanan</DataTable.Title>
        </DataTable.Header>
      <DataTable.Row>
        <DataTable.Cell>Cheese Burger</DataTable.Cell>
        <DataTable.Cell numeric>RP 32.000</DataTable.Cell>
        <IconButton icon="plus" color="#FF0000" size={24} onPress={() => console.log('Pressed')}/>
      </DataTable.Row>
      <DataTable.Row>  
        <DataTable.Cell>Mie Ayam</DataTable.Cell>
        <DataTable.Cell numeric>RP 24.000</DataTable.Cell>
        <IconButton icon="plus" color="#FF0000" size={24} onPress={() => console.log('Pressed')}/>
      </DataTable.Row>
      <DataTable.Row>  
        <DataTable.Cell>Nasi Goreng</DataTable.Cell>
        <DataTable.Cell numeric>RP 24.000</DataTable.Cell>
        <IconButton icon="plus" color="#FF0000" size={24} onPress={() => console.log('Pressed')}/>
      </DataTable.Row>
      <DataTable.Row>
        <DataTable.Cell>Ayam Bakar</DataTable.Cell>
        <DataTable.Cell numeric>RP 24.000</DataTable.Cell>
        <IconButton icon="plus" color="#FF0000" size={24} onPress={() => console.log('Pressed')}/>
      </DataTable.Row>


      <DataTable.Header>
          <DataTable.Title style={{justifyContent:'center'}}>Minuman</DataTable.Title>
        </DataTable.Header>
      <DataTable.Row>
        <DataTable.Cell>Teh Manis</DataTable.Cell>
        <DataTable.Cell numeric>Rp 7.000</DataTable.Cell>
        <IconButton icon="plus" color="#FF0000" size={24} onPress={() => console.log('Pressed')}/>
      </DataTable.Row>

      <DataTable.Row>
        <DataTable.Cell>Jus Jeruk</DataTable.Cell>
        <DataTable.Cell numeric>RP 12.000</DataTable.Cell>
        <IconButton icon="plus" color="#FF0000" size={24} onPress={() => console.log('Pressed')}/>
      </DataTable.Row>

      <DataTable.Header>
          <DataTable.Title style={{justifyContent:'center'}}>Paket</DataTable.Title>
        </DataTable.Header>
      <DataTable.Row>
        <DataTable.Cell>Paket A (Mie Ayam + Teh Manis) </DataTable.Cell>
        <DataTable.Cell numeric>Rp 30.000</DataTable.Cell>
        <IconButton icon="plus" color="#FF0000" size={24} onPress={() => console.log('Pressed')}/>
      </DataTable.Row>

  </DataTable>

  </ScrollView>
  );
};

export default SegmentedControl;
