import { StyleSheet, TextInput, View } from "react-native";
import * as React from "react";
import { ScrollView } from "react-native-web";
import {
  DataTable,
  FAB,
  Modal,
  Portal,
  Text,
  Button,
  PaperProvider,
} from "react-native-paper";
import globalStyle from "../../styles/GlobalStyle";

export default function OrderkScreen({ navigation }) {
  const [visible, setVisible] = React.useState(false);

  const showModal = () => setVisible(true);
  const hideModal = () => setVisible(false);

  const goToRoute = (nameRoute) => {
    navigation.navigate(nameRoute);
  };
  return (
    <View style={globalStyle.flex}>
      <PaperProvider>
        <View style={globalStyle.headers}>
          <Text style={{color: 'white'}}>Telur Ayam</Text>
        </View>
        <DataTable style={{ color: "#0f0" }}>
          <DataTable.Header>
            <DataTable.Title>Kode Bahan</DataTable.Title>
            <DataTable.Title>Supplier</DataTable.Title>
            <DataTable.Title numeric>Total Stock</DataTable.Title>
          </DataTable.Header>

          <DataTable.Row>
            <DataTable.Cell>A1001</DataTable.Cell>
            <DataTable.Cell>Super Ayam</DataTable.Cell>
            <DataTable.Cell numeric>50</DataTable.Cell>
          </DataTable.Row>

          <DataTable.Row>
            <DataTable.Cell>A1002</DataTable.Cell>
            <DataTable.Cell>Cap Ayam</DataTable.Cell>
            <DataTable.Cell numeric>100</DataTable.Cell>
          </DataTable.Row>

          <DataTable.Row>
            <DataTable.Cell>A1003</DataTable.Cell>
            <DataTable.Cell>Tuku Distributor</DataTable.Cell>
            <DataTable.Cell numeric>80</DataTable.Cell>
          </DataTable.Row>

        </DataTable>
        <FAB
          icon="plus"
          style={globalStyle.fab}
          onPress={showModal}
          color="#ffffff"
        />
        <Portal>
          <Modal
            visible={visible}
            onDismiss={hideModal}
            contentContainerStyle={globalStyle.modal}
          >
            <Text style={globalStyle.textModal}>Tambah Stok</Text>
            <TextInput
              style={globalStyle.textInput}
              placeholder="Jenis"
              placeholderTextColor="silver"
            />
            <TextInput
              style={globalStyle.textInput}
              placeholder="Supplier"
              placeholderTextColor="silver"
            />
            <TextInput
              style={globalStyle.textInput}
              placeholder="Satuan"
              placeholderTextColor="silver"
            />
            <TextInput
              style={globalStyle.textInput}
              placeholder="HPP"
              placeholderTextColor="silver"
            />
            <TextInput
              style={globalStyle.textInput}
              placeholder="Harga Jual"
              placeholderTextColor="silver"
            />
            <TextInput
              style={globalStyle.textInput}
              placeholder="Stok"
              placeholderTextColor="silver"
            />
            <TextInput
              style={globalStyle.textInput}
              placeholder="Stok Opnam"
              placeholderTextColor="silver"
            />
            <TextInput
              style={globalStyle.textInput}
              placeholder="Stok Minimum"
              placeholderTextColor="silver"
            />
            <View style={globalStyle.buttonModal}>
              <Button style={globalStyle.batal}>Batal</Button>
              <Button style={globalStyle.simpan}>Simpan</Button>
            </View>
          </Modal>
        </Portal>
      </PaperProvider>
    </View>
  );
}

const styles = StyleSheet.create({
 
});
