import { StyleSheet, Text, View, ScrollView } from 'react-native'
import React from 'react'
import { Button } from 'react-native-paper';
import { IconButton, MD3Colors } from 'react-native-paper';
import { Card,Title } from 'react-native-paper';

export default function MenuScreen({ navigation }) {
  
  const goToRoute = (nameRoute) => {
    navigation.navigate(nameRoute);
  };
  return (
    
    <ScrollView>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
      
      <View style={{ alignItems: 'center' }}>
      <IconButton icon="hamburger" color="#FF0000" size={24} onPress={() => goToRoute("MenuScreen2")}/>
      <Text>Burger</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="noodles" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Mie</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="coffee" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Minuman</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="rice" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Nasi</Text>
      </View>

      <View style={{ alignItems: 'center' }}>
      <IconButton icon="pizza" color="#FF0000" size={24} onPress={() => console.log('Pressed')} />
      <Text>Pizza</Text>
      </View>
      </View>

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/burger.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Burger</Title>
          </Card.Content>
      </Card>
      </View>

      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/burger2.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Chesse Burger</Title>
          </Card.Content>
      </Card>
      </View>
      </View>

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/burger3.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Chesse Burger</Title>
          </Card.Content>
      </Card>
      </View>

      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/kopi.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Kopi</Title>
          </Card.Content>
      </Card>
      </View>
      </View>

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingTop:5 }} >
      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/nasgor.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Card Title</Title>
          </Card.Content>
      </Card>
      </View>

      <View style={{ alignItems: 'center'}}>
      <Card style={{ width: 170 }}>
        <Card.Cover source={require('../../assets/burger.jpg')} style={{ height: 125 }}/>
          <Card.Content>
            <Title>Burger</Title>
          </Card.Content>
      </Card>
      </View>
      </View>


    </ScrollView>

  )
}

const styles = StyleSheet.create({})