import React, { useState, useEffect} from "react";
import {View, Text, Dimensions} from 'react-native'
import { Avatar, Button, IconButton, MD3Colors, Card, Title, TextInput} from "react-native-paper";
import globalStyle from "../../styles/GlobalStyle";
import {LineChart,} from "react-native-chart-kit";

const containerStyle = {backgroundColor: '#5D3FD3', padding: 5, flexDirection:'row', justifyContent: 'center'};
const Transaksi = () => {
  return <View style={{flex: 1}}>
  <View style={containerStyle}>

      <View style={{paddingLeft: 10, paddingTop: 5}}>
        <IconButton icon="arrow-left-drop-circle" style={{backgroundColor: 'white'}} size={20} onPress={() => goToRoute("MenuScreen")} />
      </View>
      
      <TextInput style={{ width: 75, marginLeft: 10}} label="Maret" />

      <View style={{paddingLeft: 10, paddingTop: 5}}>
        <IconButton icon="arrow-right-drop-circle" style={{backgroundColor: 'white'}} size={20} onPress={() => goToRoute("MenuScreen")} />
      </View>
  </View>
  <LineChart
    data={{
      labels: ["1", "2", "3", "4", "5", "6"],
      datasets: [
        {
          data: [
            Math.random() * 100,
            Math.random() * 100,
            Math.random() * 100,
            Math.random() * 100,
            Math.random() * 100,
            Math.random() * 100
          ]
        }
      ]
    }}
    width={Dimensions.get("window").width} // from react-native
    height={220}
    yAxisLabel="RP"
    //yAxisSuffix="k"
    yAxisInterval={1} // optional, defaults to 1
    chartConfig={{
      backgroundColor: "#white",
      backgroundGradientFrom: "#5D3FD3",
      backgroundGradientTo: "#ef493d",
      //decimalPlaces: 2, // optional, defaults to 2dp
      color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
      labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
      style: {
        borderRadius: 16
      },
      propsForDots: {
        r: "6",
        strokeWidth: "2",
        stroke: "#ffa726"
      }
    }}
    bezier
    style={{
      //marginVertical: 8,
      borderRadius: 1
    }}
  />
    <View style={{flexDirection:'row'}}>
        <Button icon="file-pdf-box" style={{marginLeft: 20, marginTop: 50, width: 150}} mode="contained" onPress={() => console.log('Pressed')}>
          ExportPDF
        </Button>
        <Button icon="printer" style={{marginLeft: 40, marginTop: 50, width: 150}} mode="contained" onPress={() => console.log('Pressed')}>
          Print
        </Button>
    </View>
  </View>
  };


export default Transaksi;