import {
  Text,
  TouchableHighlight,
  StyleSheet,
  View,
  Image,
  Alert,
  TouchableOpacity,
} from "react-native";
import * as React from "react";
import globalStyle from "../styles/GlobalStyle";
import {
  Avatar,
  Button,
  IconButton,
  MD3Colors,
  Card,
  Title,
} from "react-native-paper";
import imgIcon from "../assets/kasbon.jpg";
import api from "../utils/HttpReq";
import * as SecureStore from "expo-secure-store";

export default function HomeScreen({ navigation }) {
  const goToRoute = (nameRoute) => {
    
    navigation.navigate(nameRoute);
  };
  const getdata = async () => {
    let payload = {};
    try {
      let response = await api.get("/customer/profile", payload);
      console.log(response);
      if (response.status === 200) {
        // jika sukses ngapain?
        // let data = response.data.data;
      } else {
        alert("Hello I am Simple Alert");
      }
    } catch (error) {
      console.log(error);
      Alert.alert("Error", "Username dan Password Salah!");
    }
  };
  const getDataCart = async () => {
    let payload = {};
    try {
      let response = await api.get("/customer/cart", payload);
      console.log(response);
      if (response.status === 200) {
        // jika sukses ngapain?
        let data = response.data;
        console.log(data)
      } else {
        alert("Hello I am Simple Alert");
      }
    } catch (error) {
      console.log(error);
      Alert.alert("Error", "Username dan Password Salah!");
    }
  };
  return (
    <View style={globalStyle.container2}>
      <Image source={imgIcon} style={{ width: "100%", height: 100 }} />

      <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
        <View style={{ alignItems: "center", padding: 5 }}>
          <IconButton
            icon="cash-register"
            color="#FF0000"
            size={24}
            onPress={() => goToRoute("MenuScreen")}
          />
          <Text>Pos</Text>
        </View>

        <View style={{ alignItems: "center", padding: 5 }}>
          <IconButton
            icon="account-supervisor"
            color="#FF0000"
            size={24}
            onPress={() => console.log("Pressed")}
          />
          <Text>Pelanggan</Text>
        </View>

        <View style={{ alignItems: "center", padding: 5 }}>
          <IconButton
            icon="toolbox"
            color="#FF0000"
            size={24}
            onPress={() => goToRoute("StockScreen")}
          />
          <Text>Barang</Text>
        </View>

        <View style={{ alignItems: "center", padding: 5 }}>
          <IconButton
            icon="clipboard-check"
            color="#FF0000"
            size={24}
            onPress={() => goToRoute("Transaksi")}
          />
          <Text>Transaksi</Text>
        </View>

        <View style={{ alignItems: "center", padding: 5 }}>
          <IconButton
            icon="truck-cargo-container"
            color="#FF0000"
            size={24}
            onPress={() => console.log("Pressed")}
          />
          <Text>Supplier</Text>
        </View>
      </View>

      {/* rowbaru */}

      <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
        <View style={{ alignItems: "center", padding: 5 }}>
          <IconButton
            icon="dropbox"
            color="#FF0000"
            size={24}
            onPress={() => console.log("Pressed")}
          />
          <Text>Konversi</Text>
        </View>

        <View style={{ alignItems: "center", padding: 5 }}>
          <IconButton
            icon="chart-areaspline"
            color="#FF0000"
            size={24}
            onPress={() => goToRoute("Transaksi")}
          />
          <Text>Penjulaan</Text>
        </View>

        <View style={{ alignItems: "center", padding: 5 }}>
          <IconButton
            icon="shopping"
            color="#FF0000"
            size={24}
            onPress={() => console.log("Pressed")}
          />
          <Text>PO</Text>
        </View>

        <View style={{ alignItems: "center", padding: 5 }}>
          <IconButton
            icon="handshake"
            color="#FF0000"
            size={24}
            onPress={() => console.log("Pressed")}
          />
          <Text>Penerimaan</Text>
        </View>

        <View style={{ alignItems: "center", padding: 5 }}>
          <IconButton
            icon="printer"
            color="#FF0000"
            size={24}
            onPress={() => console.log("Pressed")}
          />
          <Text>Print</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.button} onPress={() => getdata()}>
        <Text style={styles.textButton}>LOGIN</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={() => getDataCart()}>
        <Text style={styles.textButton}>CRAT</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({});
