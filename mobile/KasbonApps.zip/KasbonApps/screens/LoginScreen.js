import {
  Text,
  StyleSheet,
  View,
  Button,
  Touchable,
  TouchableOpacity,
  TextInput,
  Alert,
  Image
} from "react-native";
import imgIcon from '../assets/kasbon.jpg';
import React, { Component } from "react";
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import api from "../utils/HttpReq";
import * as SecureStore from 'expo-secure-store';

export default class LoginScreen extends Component {
  constructor(props) {
    super(props);


    this.state = {
      username: "demoresto",
      password: "demo123",
      isLogin: false,
    };
  }
  

  login = async () => {
    let payload = {
      "email" : 'cashier@blog.com',
      "password" : 'abdurojak27'
      // "email" : this.state.username,
      // "password" : this.state.password
  }
  try{
    let response = await api.post('/login', payload);
    if(response.status === 200) {
      await SecureStore.setItemAsync('token', response.data.data.token)
      await SecureStore.setItemAsync('data', JSON.stringify(response.data.data))
      this.props.navigation.navigate('HomeScreen')
  
      // cara nge get data dari storage
      // let datanya = await SecureStore.getItemAsync('data')
      // let tokennya = await SecureStore.getItemAsync('token')
      // console.log(datanya)
      // console.log(tokennya)
    } else {
      alert('Hello I am Simple Alert');
    }
  }catch(error) {
    console.log(error)
    Alert.alert("Error", "Username dan Password Salah!");

  }
  // console.log(response)
  // let token = response.data.token
  // await SecureStore.setItemAsync('token', token);

    // if (this.state.username === "demoresto" && this.state.password === "demo123") {
    //   this.setState({
    //     isLogin: true,
    //   });
    // } else {
    //   Alert.alert("Error", "Username dan Password Salah!");
    // }
  };
  render() {
    const goToRoute = (nameRoute) => {
        navigation.navigate(nameRoute);
      };
    
    const { isLogin } = this.state;
    return (
      <View style={styles.container}>
        <Image source={imgIcon} style={{ width: '100%', height: 100 }}/>

        {/* isi */}
        <View style={styles.isi}>
          <View style={styles.wrapperInput}>
            <Text>Username : </Text>
            <TextInput
              style={styles.textInput}
              placeholder="Masukan Username"
              onChangeText={(username) => this.setState({ username })}
            />
          </View>
          <View style={styles.wrapperInput}>
            <Text>Password : </Text>
            <TextInput
              style={styles.textInput}
              placeholder="Masukan Password"
              onChangeText={(password) => this.setState({ password })}
              secureTextEntry={true}
            />
          </View>

          <TouchableOpacity style={styles.button} onPress={() => this.login()}>
            <Text style={styles.textButton}>LOGIN</Text>
          </TouchableOpacity>

          {isLogin && (
             this.props.navigation.navigate('HomeScreen')
          )}
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: { padding: 30 },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    textAlign: "center",
  },
  garis: {
    borderBottomWidth: 1,
    marginTop: 10,
  },
  isi: {
    marginTop: 30,
  },
  textInput: {
    borderWidth: 1,
    padding: 10,
    borderColor: "grey",
    borderRadius: 5,
    height: 40,
  },
  wrapperInput: {
    marginTop: 20,
  },
  button: {
    marginTop: 20,
    backgroundColor: "navy",
    padding: 10,
    borderRadius: 5,
  },
  textButton: {
    textAlign: "center",
    fontWeight: "bold",
    color: "white",
  },
});
