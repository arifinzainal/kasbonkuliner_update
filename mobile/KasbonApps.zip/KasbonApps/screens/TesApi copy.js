import {
    StyleSheet,
    Text,
    View,
    TextInput,
  } from "react-native";
  import React , { useState } from "react";
  import { Button } from "react-native-paper";
  import globalStyle from "../styles/GlobalStyle";
  import api from "../utils/HttpReq";
  // import axios from 'axios';
  
  export default function SplashScreen({ navigation }) {
    const goToRoute = (nameRoute) => {
      navigation.navigate(nameRoute);
    };
  
    var idm = 10;
  
    const [dataAtas, setData] = useState(null)
  
    const getData = async () => {
      // const tmpdata = await api.get("/todos/");
      const tmpdata = await api.get();
      console.log(tmpdata);
      setData(tmpdata);
      //   axios.get('https://jsonplaceholder.typicode.com/todos/1')
      // .then(response => {
      //   console.log(response.data);
      // })
      // .catch(error => {
      //   console.error(error);
      // });
    };
    return (
      <View style={globalStyle.container}>
        <View>
          <TextInput editable onChangeText={(text) => this.setState({idm: text})} />
          <Text>{dataAtas && JSON.stringify(dataAtas.data[0]).toString()}</Text>
          {
            dataAtas && dataAtas.data.map(v => {
              return <>
              <Text>{v.title}</Text>
              </>
            })
          }
          <Text>SplashScreen</Text>
          {/* <TouchableHighlight onPress={() => goToRoute("LoginScreen")}>
            <Text>Goto Loginpage</Text>
          </TouchableHighlight> */}
          <Button
            icon="arrow-right"
            contentStyle={{ flexDirection: "row-reverse" }}
            mode="contained"
            onPress={() => getData()}
            style={globalStyle.txt}
          >
            GetDatabiss
          </Button>
         
  
          <Button
            icon="arrow-right"
            contentStyle={{ flexDirection: "row-reverse" }}
            mode="contained"
            onPress={() => goToRoute("SplashScreen")}
            style={globalStyle.txt}
          >
            Goto Home
          </Button>
        </View>
      </View>
    );
  }
  
  const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
    },
    row: {
      flexDirection: "row",
    },
    column: {
      flex: 1,
      padding: 10,
    },
  });
  