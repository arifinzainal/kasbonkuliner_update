import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import { PaperProvider } from 'react-native-paper';

// import screen here ----------------------------------------------------------------
import SplashScreen from './screens/SplashScreen';
import HomeScreen from './screens/HomeScreen';
import LoginScreen from './screens/LoginScreen';
import TesApi from './screens/TesApi';
import StockScreen from './screens/stock/StockScreen';
import DetailStockScreen from './screens/stock/DetailStockScreen';
import ManageStockScreen from './screens/stock/ManageStockScreen';
import MenuScreen from './screens/Pos/MenuScreen';
import MenuScreen2 from './screens/Pos/MenuScreen2';
import FiturMenu from './screens/Pos/FiturMenu';
import AddStockScreen from './screens/stock/AddStockScreen';
import Transaksi from './screens/Penjualan/Transaksi';
import Pembayaran from './screens/Pos-kasir/Pembayaran';
import Kasir from './screens/Pos-kasir/Kasir';
// [end] import screen here ----------------------------------------------------------------


// Create a stack navigator
const Stack = createStackNavigator();

export default function App() {
  return (
    // <View style={styles.container}>
    //   <Text>Open up App.js to start working on your app!</Text>
    //   <StatusBar style="auto" />
    // </View>
    <NavigationContainer>
      <Stack.Navigator initialRouteName="SplashScreen">
        <Stack.Screen name="SplashScreen" component={SplashScreen} options={{ headerShown: false }} />
        <Stack.Screen name="LoginScreen" component={LoginScreen} />
        <Stack.Screen name="HomeScreen" component={HomeScreen} />
        <Stack.Screen name="MenuScreen" component={MenuScreen} />
        <Stack.Screen name="MenuScreen2" component={MenuScreen2} />
        <Stack.Screen name="FiturMenu" component={FiturMenu} />
        <Stack.Screen name="StockScreen" component={StockScreen} />
        <Stack.Screen name="AddStockScreen" component={AddStockScreen} />
        <Stack.Screen name="DetailStockScreen" component={DetailStockScreen} />
        <Stack.Screen name="ManageStockScreen" component={ManageStockScreen} />
        <Stack.Screen name="Transaksi" component={Transaksi} />
        <Stack.Screen name="Pembayaran" component={Pembayaran} />
        <Stack.Screen name="Kasir" component={Kasir} />
        <Stack.Screen name="TesApi" component={TesApi} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
