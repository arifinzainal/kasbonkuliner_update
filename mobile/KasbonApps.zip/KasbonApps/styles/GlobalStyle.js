import { StyleSheet } from "react-native";

const globalStyle = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  //HomeScreen
  container2: {
    flex: 1,
    padding: 16
    
  },
  flex: {
    flex: 1,
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 16,
  },
  button: {
    backgroundColor: "#007bff",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  buttonText: {
    color: "#ffffff",
    fontSize: 16,
    fontWeight: "bold",
  },
  row: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  fab: {
    backgroundColor: "#5D3FD3",
    position: "absolute",
    margin: 16,
    right: 0,
    bottom: 0,
  },
  column: {
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
  },

  // stok
  headers: {
    backgroundColor: "#5D3FD3",
    justifyContent: "center",
    alignItems: "center",
    height: 50,
  },
  txtwhite: {
    backgroundColor: "#FFFFFF",
    width: 300,
    padding: 3
  },
  txt: {
    margin: 2,
  },
  textInput: {
    margin: 5,
    fontSize: 16,
    borderWidth: 1,
    borderRadius: 5,
    textAlign: 'center',
  },

  textModal: {
    fontWeight: 'bold',
    textAlign: 'center',
  },

  modal: { backgroundColor: "white", margin: 20, padding: 5, paddingTop: 20, paddingBottom: 20 },

  buttonModal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  Modalhapus: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  batal :{
    color: '#FFFFFF',
    backgroundColor : "#f55",
    borderRadius : 10,
    padding : 1,
    margin : 5,
  },
  simpan : {
    color: '#FFFFFF',
    backgroundColor : "#5f5",
    borderRadius : 10,
    padding : 1,  
    margin : 5,
  }
  // end of stok
});

export default globalStyle;
